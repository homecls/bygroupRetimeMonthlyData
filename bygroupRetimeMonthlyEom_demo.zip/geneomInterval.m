function Date = geneomInterval(Dstart,Dend)
% Date = geneomInterval([year1 m1],[year2, m2])
% Date = geneomInterval(tDatenum)
%% Method 1:
% geneomInterval(Dstart,Dend)
% Dstart = [year1 m1]; Dend =[year2, m2]
%% Method 2:
% geneomInterval(Datenum)
% % Datenum is a vector of datenum
%% Example
% dnnew = geneomInterval([min(year(dnorg)),1],[max(year(dnorg)),12]);

if nargin==2
    year1= Dstart(1);  month1 = Dstart(2);
    year2= Dend(1);  month2 = Dend(2);
elseif nargin==1
    dn = Dstart; % a sequence of datenum
    dmin = min(dn); 
    dmax = max(dn);
    year1= year(dmin);  month1 = month(dmin);
    year2= year(dmax);  month2 = month(dmax);
else
    error('nargin should be 1 or 2')
end
ym = NaN((year2-year1+1)*12,2);
kk = 1;
for ii=1:year2-year1+1
   for jj = 1:12
      ym(kk,:) = [year1+ii-1 jj];
      if ii==1 && jj==month1; id1 = kk;
      elseif  ii==year2-year1+1 && jj == month2; id2 = kk;
      end;
       kk = kk+1;
   end
end

ym = ym(id1:id2,:);
Date = eomdate(ym(:,1), ym(:,2));
% Date = NaN(length(ym),1);
% for ii = 1:length(ym)
%     Date(ii) = eomdate(ym(ii,1), ym(ii,2));
% end


end