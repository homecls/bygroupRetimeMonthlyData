function [uniques,ia,ic,Tvarnamesunique] = uniqueCount(varargin)
% [uniques,ia,ic,Tvarnamesunique] = uniqueCount(varargin) 
[uniques,ia,ic] = unique(varargin{:}); % {'%';'��Ԫ';'����=100';'��Ԫ';'Ԫ'}
[~,numUnique] = count_unique(ic);
if istable(uniques)
    Tvarnamesunique = uniques;
    Tvarnamesunique.numUnique = numUnique;
else
    Tvarnamesunique = table(uniques,numUnique);
end


