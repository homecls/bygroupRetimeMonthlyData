function tDatenum = makeitDatenum(tRaw)

iclass = class(tRaw);
if iscellstr(tRaw)
    iclass = 'cellstr';
end
switch iclass
    case {'datetime'}
        tDatenum = datenum(tRaw);
    case {'string','cellstr'} % ["1990-1-2";"1990-3-2"],{'1999-01-02','1998-03-04'};
        tDatenum = datenum(tRaw);
    case {'double'}
        if all(tRaw > datenum('800-01-31'))
            tDatenum = tRaw;
        else
            error('the datenum format mis-matched')
        end
    otherwise
        error('the time format mis-matched')
end

end