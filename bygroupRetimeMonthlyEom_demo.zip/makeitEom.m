function tDatenumEom = makeitEom(tDatenum)
% convert datenum to datenumEom

Years = year(tDatenum);
Months = month(tDatenum);
tDatenumEom = eomdate(Years,Months);
[us,ia,ic,iT] = uniqueCount(tDatenumEom);
if any(iT.numUnique>1)
    iT.Datestr = string(datestr(iT.uniques));
    disp(iT);
    warning('Time variable are not unique as DatenumEom');
end
end